/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica1;

import java.io.IOException;
import java.util.Observable;
import java.util.Observer;


/**
 *
 * @author raquel
 */
public class Console implements Observer{
    
    static final String ANSI_DRETA = "\033[C";
    static final String ANSI_ESQUERRA = "\033[D";
    static final String ANSI_INSERTAR = "\033[4h";
    static final String ANSI_BACKSPACE = "\b";
    static final String ANSI_ELIMINAR = "\033[P";
    static final String ANSI_HOME = "\033[1~";  
    static final String ANSI_FIN = "\033[4~";
    static final String ANSI_ESPAI = "\033[ ";
    static final String ANSI_ESPAI_BLANC = "\033[@";
    
    private Line linia;
    
    
    public Console(Line value){
        this.setRaw();
        this.linia =value;
    }
    
   
    static final int SEC_BACKSPACE = 127;
    static final int ESCAPE_SEC = 5000; 
    static final int SEC_HOME = 5000;
    static final int SEC_DRETA = 5001;
    static final int SEC_ESQUERRA = 5002;
    static final int SEC_FIN = 5003;
    static final int SEC_INSERTAR = 5004;
    static final int SEC_ELIMINAR = 5005;
    static final int CARACTER = 5006;
    static final int FINAL = 5007;
    
    public void update(Observable obs, Object obj){
        int var = (int)obj;
        switch(var){
            case CARACTER: 
                boolean aux = this.linia.getInsert();
                this.printChar(this.linia.getUltimCaracter(), aux);
            break;
            
            case SEC_DRETA:
                this.dreta();
            break;
            
            case SEC_ESQUERRA:
                this.esquerra();
            break;
            
            case SEC_HOME: 
                this.updateCursor(this.linia.getPosicio());
                
            break;
            
            case SEC_FIN:
                this.updateCursor(this.linia.getPosicio());
            break;
            
            case SEC_BACKSPACE:
                this.backspace();
            break;
            
            case SEC_ELIMINAR:
                this.eliminar();
            break;
            
            case FINAL:
                this.unsetRaw();
            break;
            
            case SEC_INSERTAR:
                this.insertar();
            break;
            default:
            break;
        }
    }
    
    public void insertar(){
        System.out.print(ANSI_INSERTAR);
    }
    
    public void setRaw(){
        String cmd[] = {"/bin/sh", "-c", "stty -echo raw </dev/tty"};
        try{
            Runtime.getRuntime().exec(cmd);
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }
    
    public void unsetRaw(){
        String cmd[] = {"/bin/sh", "-c", "stty echo cooked </dev/tty"};
        try{
            Runtime.getRuntime().exec(cmd);
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }
    public void eliminar(){
        System.out.print(ANSI_ELIMINAR);
    }
    public void backspace(){
        System.out.print(ANSI_ELIMINAR);
    }
    public void dreta(){
        System.out.print(ANSI_DRETA);
    }
    public void esquerra(){
        System.out.print(ANSI_ESQUERRA);
    }
    public void printChar(char a, boolean insertar){
        if(insertar){
            System.out.print(a);
        }else{
            System.out.print(ANSI_ESPAI_BLANC);
            System.out.print(a);
        }
    }
    public void updateCursor(int cursorPos){
        int aux = cursorPos + 1;
        System.out.print("\033["+aux+"G");
    }
}
