/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1_mvc;

import java.util.*;
/**
 *
 * @author raquel
 */
public class Line extends Observable{

  
    
    static final int SEC_BACKSPACE = 127;
    static final int ESCAPE_SEC = 5000; 
    static final int SEC_HOME = 5000;
    static final int SEC_DRETA = 5001;
    static final int SEC_ESQUERRA = 5002;
    static final int SEC_FIN = 5003;
    static final int SEC_INSERTAR = 5004;
    static final int SEC_ELIMINAR = 5005;
    static final int CARACTER = 5006;
    static final int FINAL = 5007;
    
    ArrayList<Integer> bufferDeLinia;
    Boolean insert;
    int cursor, llargada;
    char ultimCaracter;
    
    public int getPosicio(){
        return this.cursor;
    }
    public boolean getInsert(){
        return insert;
    }
    public char getUltimCaracter(){
        
        return this.ultimCaracter;
    }
    public Line(){
        this.insert = false;
        this.bufferDeLinia = new ArrayList<>();
        this.cursor = 0;
        this.llargada = 0;
        
    }
   
    
    public String returnStr(){
        String str = "";
        int i = 0;
        int aux = 0;
        for(i=0; i<this.bufferDeLinia.size(); i++){
            aux = this.bufferDeLinia.get(i);
            str += (char)aux;
        }
        
        return str;
    }
    public void eliminarCaracter(int pos){
        this.bufferDeLinia.remove(pos);
    }
    public void canviarInsert(){
        this.insert = !this.insert;
        this.setChanged();
        this.notifyObservers(SEC_INSERTAR);
    }
    
    public void afegirCaracter(int a){
        if(this.insert){
            if(this.cursor < this.bufferDeLinia.size()){
                this.bufferDeLinia.set(this.cursor, a);
            }else{
                this.bufferDeLinia.add(this.cursor, a);
            }
        }else{
            int i = 0;
            this.llargada = this.bufferDeLinia.size();
            if(this.cursor < this.llargada){
                for(i=this.llargada; i>this.cursor; i--){
                    this.bufferDeLinia.add(i,this.bufferDeLinia.get(i-1));
                    this.bufferDeLinia.remove(i-1);
                }    
            }
            this.bufferDeLinia.add(this.cursor, a);
        }
        char aux = (char)a;
        this.ultimCaracter = (char)a;
        this.cursor ++;
        this.setChanged();
        this.notifyObservers(CARACTER);
    }

    public void Home(){
        this.cursor = 0;
        this.setChanged();
        this.notifyObservers(SEC_HOME);
    }

    public void Fin(){
        this.cursor = this.bufferDeLinia.size();
        this.setChanged();
        this.notifyObservers(SEC_FIN);
    }
    
    public void Eliminar(){
        if(this.cursor < this.bufferDeLinia.size()){
            this.bufferDeLinia.remove(this.cursor);
            this.llargada--;
            
        }
        this.setChanged();
        this.notifyObservers(SEC_ELIMINAR);
    }

    public void Backspace(){
        if((this.cursor <= this.bufferDeLinia.size())&&(this.bufferDeLinia.size()>0) && this.cursor > 0){
            this.bufferDeLinia.remove(this.cursor-1);
            this.Esquerra();
            this.llargada--;
        }
        this.setChanged();
        this.notifyObservers(SEC_BACKSPACE);
 
    }

    public void Dreta(){
        if(this.cursor < this.bufferDeLinia.size()){
            this.cursor++;
        }
        this.setChanged();
        this.notifyObservers(SEC_DRETA);
    }

    public void Esquerra(){
        if(this.cursor > 0){
            this.cursor--;
        }
        this.setChanged();
        this.notifyObservers(SEC_ESQUERRA);
    }   
    public void Enter(){
        this.setChanged();
        this.notifyObservers(FINAL);
 
    }

}
