/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1_mvc;
import project1_mvc.Line;


import java.io.*;
import java.util.*;
/**
 *
 * @author raquel
 */
public class EditableBufferedReader extends BufferedReader{
    Line linia;
    Console consola;
        int posicio, llargada;
        static final int ESC = 27;
        static final int BACKSPACE = 127;
        static final int DRETA = 67;
        static final int ESQUERRA = 68;
        static final int HOME = 72;
        static final int END = 70;
        static final int INSERTAR = 50;
        static final int ELIMINAR = 51;
        static final int CORCHETE = 91;
        static final int TRONCHO = 126; 
        static final int INTERROGANT = 63;
        static final int ENTER = 13;
        
        static final int SEC_BACKSPACE = 127;
        static final int ESCAPE_SEC = 5000; 
        static final int SEC_HOME = 5000;
        static final int SEC_DRETA = 5001;
        static final int SEC_ESQUERRA = 5002;
        static final int SEC_FIN = 5003;
        static final int SEC_INSERTAR = 5004;
        static final int SEC_ELIMINAR = 5005;
 

    public EditableBufferedReader(Reader in){
        super(in);
        this.linia = new Line();
        this.consola = new Console(this.linia);
        this.linia.addObserver(this.consola);
        this.posicio  = 0;
        this.llargada = 0;
    }
    
    
    @Override
    public  int read() throws IOException{
        
        int caracter = 0;
        caracter = super.read();
        if(caracter == ESC){
            caracter = super.read();
            if(caracter == CORCHETE){       
                caracter = super.read();
                switch(caracter){
                    case DRETA:
                        return SEC_DRETA;
                  
                    case ESQUERRA:
                        return SEC_ESQUERRA;
                    
                    case HOME:
                        return SEC_HOME;
                    
                    case END:
                        return SEC_FIN; 
                    
                    case INSERTAR:
                        caracter = super.read();
                        if(caracter == TRONCHO){
                            return SEC_INSERTAR;
                        }
                        return -1;
                    
                    case ELIMINAR:
                        caracter = this.read();
                        if(caracter == TRONCHO){
                            return SEC_ELIMINAR;
                        }
                        return -1;
                    
                    default:
                        return -1;
                    
                }
            }
        }else if(caracter == BACKSPACE){
            return BACKSPACE;
        }else{  
            return caracter;
        }
        return -1;
    }
    public String readLine() throws IOException{
        
        int caracter = 0;
        do{ 
            caracter = this.read();
            if(caracter >= ESCAPE_SEC){
                switch (caracter){
                    case SEC_INSERTAR:
                        this.linia.canviarInsert();
                    break;
                    case SEC_ELIMINAR:
                        this.linia.Eliminar();
                    break;
                    case SEC_FIN:
                        this.linia.Fin();
                    break;
                    case SEC_HOME:
                        this.linia.Home();
                    break;
                    case SEC_ESQUERRA:
                        this.linia.Esquerra();
                    break;
                    case SEC_DRETA:
                        this.linia.Dreta();
                    break;
                }
            }
            else if (caracter == SEC_BACKSPACE){
                this.linia.Backspace();
                
            }

            else if (caracter != ENTER){
                this.linia.afegirCaracter(caracter);
            }
        }while(caracter != ENTER);        
        this.linia.Enter();
        return this.linia.returnStr();
    }
}
